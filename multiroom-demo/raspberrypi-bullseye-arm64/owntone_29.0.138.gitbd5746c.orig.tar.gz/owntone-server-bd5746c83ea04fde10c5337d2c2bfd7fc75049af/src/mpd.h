
#ifndef __MPD_H__
#define __MPD_H__


int
mpd_init(void);

void
mpd_deinit(void);

#endif /* !__MPD_H__ */
